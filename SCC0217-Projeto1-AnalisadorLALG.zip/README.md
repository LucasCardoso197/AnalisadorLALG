# AnalisadorLALG
Analisador léxico e sintático da linguagem LALG, feito com uso das ferramentas lex e yacc.

Dependencias: Pacote flex e bison.

Comandos (makefile):
```
make - Compila os arquivos de código e gera um executavel a.out.
make test - Executa utilizando o arquivo input.txt como entrada.
make run - Executa utilizando a entrada padrão como entrada.
```
